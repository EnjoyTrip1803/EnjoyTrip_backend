-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: enjoytrip
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sido`
--

DROP TABLE IF EXISTS `sido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sido` (
  `sido_code` int NOT NULL,
  `sido_name` varchar(30) DEFAULT NULL,
  `img` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`sido_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sido`
--

LOCK TABLES `sido` WRITE;
/*!40000 ALTER TABLE `sido` DISABLE KEYS */;
INSERT INTO `sido` VALUES (1,'서울','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=1c9629a8-f3cc-4a1f-adde-10c7424285ce'),(2,'인천','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=1229ae98-0815-45d4-8706-291f0d7282ea'),(3,'대전','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=222c111f-1a82-49e7-88ed-cadb1e493600'),(4,'대구','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=23400c06-4f6a-42a4-9926-eeda305ab371'),(5,'광주','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=a125d7aa-2b29-4127-a7ee-4262b52bd0f4'),(6,'부산','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=58a44a35-5f34-4a39-a780-a292d8e76a3d'),(7,'울산','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=db20690c-4853-4587-b9cc-536047a845bc'),(8,'세종특별자치시','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=99559a52-3574-405e-94ae-2fc5790d6dd1'),(31,'경기도','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=6b63e7cd-ee58-46f3-9d73-300003bed932'),(32,'강원도','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=454fa691-ae5c-4602-bb68-b364fce56045'),(33,'충청북도','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=95040ee3-c3f8-4310-9c70-6aee7390ccf9'),(34,'충청남도','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=9ab9b5dc-5b9b-4bac-8036-6582d941b0ff'),(35,'경상북도','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=ad190f4d-bcb3-4e2e-8918-023690d83880'),(36,'경상남도','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=b4159508-b0f8-4511-90c2-701c17c96541'),(37,'전라북도','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=f74c2490-1af3-444d-888b-ab32b7b76d54'),(38,'전라남도','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=7dfa7d4b-e797-432b-b8ae-87a4ae902002'),(39,'제주도','https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=5a67d62c-2ac6-421a-9aa4-34df0066ba47');
/*!40000 ALTER TABLE `sido` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-22 21:38:09
